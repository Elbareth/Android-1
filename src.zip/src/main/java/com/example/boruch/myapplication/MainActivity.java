package com.example.boruch.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Button1(View view){
        TextView button1=(TextView) findViewById(R.id.button1);
        button1.setText("Przycisk1");
    }
    public void Button2(View view){
        TextView button2=(TextView) findViewById(R.id.button2);
        button2.setText("Przycisk2");
    }
    public void Button3(View view){
        TextView button3=(TextView) findViewById(R.id.button3);
        button3.setText("Przycisk3");
    }
    public void Zatwierdz(View view){
        TextView wyswietl1=(TextView) findViewById(R.id.wyswietl);
        TextView wyswietl2 = (TextView) findViewById(R.id.wyswietl2) ;
        EditText imie = (EditText) findViewById(R.id.message);
        String wyswietl = imie.getText().toString();
        EditText nazwisko = (EditText) findViewById(R.id.message2);
        String wyswiet2 = nazwisko.getText().toString();
        wyswietl1.setText(wyswietl);
        wyswietl2.setText(wyswiet2);
    }
}
